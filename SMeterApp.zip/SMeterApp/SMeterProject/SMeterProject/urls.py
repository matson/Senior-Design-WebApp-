from django.conf.urls import url, include
from django.contrib import admin
from.import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^articles/',include('articles.urls')),
    url(r'^about/$',views.about), #about page
    url(r'^$',views.homepage), #home page

]

urlpatterns += staticfiles_urlpatterns()
#where we route urls/data to different pages...

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)