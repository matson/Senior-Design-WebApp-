from django.http import HttpResponse
from django.shortcuts import render


#home page
def homepage(request):
    #return HttpResponse('homepage')
    return render(request, 'homepage.html')
#about page
def about(request):
    #return HttpResponse("about")
    return render(request, 'aboutpage.html')